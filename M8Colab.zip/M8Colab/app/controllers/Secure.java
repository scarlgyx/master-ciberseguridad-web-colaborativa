package controllers;

import helpers.HashUtils;
import models.User;
import play.i18n.Messages;
import play.libs.Crypto;
import play.mvc.Controller;

public class Secure extends Controller {

    public static void login(){
        render();
    }

    public static void logout(){
        session.clear();
        login();
    }

    public static void authenticate(String username, String password){
        User u = User.loadUser(username);
        if (u != null && u.getPassword().equals(HashUtils.getMd5(password))){
            session.clear();

            session.put("username", username);

            // Guardamos el user-agent y la IP firmados
            String userAgent = request.headers.get("user-agent").value();
            String ipAddress = request.remoteAddress;

            // Guardamos el valor firmado de UA e IP en la sesión
            session.put("signedUa", Crypto.sign(userAgent));
            session.put("signedIp", Crypto.sign(ipAddress));

            // Redirigimos a la vista de inicio
            Application.index();
        } else {
            flash.put("error", Messages.get("Public.login.error.credentials"));
            login();
        }
    }
}
