package controllers;

import models.Constants;
import models.User;
import play.libs.Crypto;
import play.mvc.*;

import java.util.List;

public class Application extends Controller {

    @Before
    static void checkSessionIntegrity() {

        String signedUa = session.get("signedUa");
        String signedIp = session.get("signedIp");

        // Muestra los valores de la cookie en la consola para pruebas
        System.out.println("DEBUG | signedUa: " + signedUa);
        System.out.println("DEBUG | signedIp: " + signedIp);

        // Verificación de la integridad de la sesión
        String userAgent = request.headers.get("user-agent").value();
        String ipAddress = request.remoteAddress;

        // Verifica si la sesión es válida comparando el UA y la IP con los valores firmados
        if (signedUa == null || signedIp == null) {
            session.clear();
            flash.put("error", "Sesión inválida o manipulada.");
            Secure.login();
        }

        // Firmamos el user-agent y la IP y los comparamos
        if (!Crypto.sign(userAgent).equals(signedUa) || !Crypto.sign(ipAddress).equals(signedIp)) {
            session.clear();
            flash.put("error", "Sesión inválida o manipulada.");
            Secure.login();
        }
    }

    private static void checkUser(){
        if (session.contains("username")){
            User u = User.loadUser(session.get("username"));
            if (u != null){
                renderArgs.put("user", u);
                return;
            }
        }
        Secure.login();
    }

    private static void checkTeacher(){
        checkUser();
        User u = (User) renderArgs.get("user");
        if (!u.getType().equals(Constants.User.TEACHER)){
            return;
        }
    }

    public static void index() {
        checkUser();
        User u = (User) renderArgs.get("user");

        if (u.getType().equals(Constants.User.TEACHER)){
            List<User> students = User.loadStudents();
            render("Application/teacher.html", u, students);
        } else {
            render("Application/student.html", u);
        }
    }

    public static void removeStudent(String student) {
        checkTeacher();
        User.remove(student);
        index();
    }

    public static void setMark(String student) {
        User u = User.loadUser(student);
        render(u);
    }

    public static void doSetMark(String student, Integer mark) {
        User u = User.loadUser(student);
        u.setMark(mark);
        u.save();
        index();
    }
}
